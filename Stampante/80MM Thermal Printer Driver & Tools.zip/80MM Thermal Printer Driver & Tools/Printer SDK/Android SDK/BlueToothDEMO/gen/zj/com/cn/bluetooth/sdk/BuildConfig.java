/** Automatically generated file. DO NOT MODIFY */
package zj.com.cn.bluetooth.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}